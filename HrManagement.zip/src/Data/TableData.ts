import { Edit, Trash2 } from "lucide-react";
import type { ReportTableConfig } from "../Components/ReportTable/ReportTable";

export const attendanceTableConfig: ReportTableConfig  = {
	selectable: true,
	pagination: true,
	rowsPerPage: 10,
	actions: [
		{
			icon: Edit,
			action: "edit",
		},
		{
			icon: Trash2,
			action: "delete",
		},
	],

	headers: [
		{ label: "EMPLOYEE ID", key: "employeeId", cellType: "text", },
		{ label: "EMPLOYEE", key: "name", cellType: "employee", },
		{ label: "DEPARTMENT", key: "department", cellType: "text", },
		{ label: "DATE", key: "date", cellType: "text", },
		{ label: "STATUS", key: "status", cellType: "status", },
	],

	rows: [
		{
			id: 1,
			employeeId: "EMP-1001",
			name: "Alex Rivers",
			email: "alex@nexus.com",
			avatar: "https://i.pravatar.cc/150?img=11",
			department: "Engineering",
			date: "10-Jun-2026",
			status: "Present",
		},
		{
			id: 2,
			employeeId: "EMP-1002",
			name: "Sarah Chen",
			email: "sarah@nexus.com",
			avatar: "https://i.pravatar.cc/150?img=12",
			department: "Design",
			date: "10-Jun-2026",
			status: "Absent",
		},
		{
			id: 3,
			employeeId: "EMP-1001",
			name: "Alex Rivers",
			email: "alex@nexus.com",
			avatar: "https://i.pravatar.cc/150?img=11",
			department: "Engineering",
			date: "10-Jun-2026",
			status: "Present",
		},
		{
			id: 4,
			employeeId: "EMP-1002",
			name: "Sarah Chen",
			email: "sarah@nexus.com",
			avatar: "https://i.pravatar.cc/150?img=12",
			department: "Design",
			date: "10-Jun-2026",
			status: "Absent",
		},
	],
};

export const employeeTableConfig: ReportTableConfig = {
	selectable: true,

	pagination: true,

	rowsPerPage: 10,

	actions: [
		{
			icon: Edit,
			action: "edit",
		},
	],

	headers: [
		{
			label: "EMPLOYEE ID",
			key: "employeeId",
			cellType: "text",
		},
		{
			label: "EMPLOYEE",
			key: "name",
			cellType: "employee",
		},
		{
			label: "ROLE",
			key: "role",
			cellType: "pill",
		},
		{
			label: "EMAIL",
			key: "email",
			cellType: "text",
		},
		{
			label: "ACTIVE",
			key: "isActive",
			cellType: "toggle",
		},
	],

	rows: employeeRows,
};

export const leaveTableConfig: ReportTableConfig = {
	selectable: true,

	pagination: true,

	rowsPerPage: 10,

	actions: [
		{
			icon: Edit,
			action: "approve",
		},
		{
			icon: Trash2,
			action: "reject",
		},
	],

	headers: [
		{
			label: "EMPLOYEE",
			key: "name",
			cellType: "employee",
		},
		{
			label: "LEAVE TYPE",
			key: "leaveType",
			cellType: "pill",
		},
		{
			label: "FROM",
			key: "fromDate",
			cellType: "text",
		},
		{
			label: "TO",
			key: "toDate",
			cellType: "text",
		},
		{
			label: "STATUS",
			key: "status",
			cellType: "status",
		},
	],

	rows: leaveRows,
};

