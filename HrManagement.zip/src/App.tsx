import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import "./App.css";
import AppLayout from "./Components/AppLayout/AppLayout";
import AttendanceManagement from "./Pages/AttendanceManagement/AttendanceManagement";

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/">
                    {/* <Route path="/" element={<WebLayout />}>
							<Route index element={<Navigate to="web" replace />} />
							<Route path="web" element={<LandingPage />} />
							<Route path="login" element={<Login />} />
							<Route path="signup" element={<Signup />} />
							<Route path="forgot-password" element={<ForgotPassword />} />
						</Route> 
					*/}
                    <Route path="/app" element={<AppLayout />}>
                        <Route
                            index
                            element={<Navigate to="dashboard" replace />}
                        />
                        <Route path="dashboard" element={<AttendanceManagement />} />
                    </Route>
                </Route>
            </Routes>
        </BrowserRouter>
    );
}

export default App;
