import { CalendarClock, CalendarDays, FileText, LayoutDashboard, Settings, Users, Wallet } from "lucide-react";

export const sidebarData = [
	{
		id: 1,
		title: "Dashboard",
		icon: "dashboard",
		path: "/dashboard"
	}, {
		id: 2,
		title: "Employees",
		icon: "groups",
		path: "/employees"
	}, {
		id: 3,
		title: "Attendance",
		icon: "calendar_today",
		path: "/attendance"
	}, {
		id: 4,
		title: "Salary",
		icon: "payments",
		path: "/salary"
	},
];

const navigationItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, path: "/" },
    { id: "employee", label: "Employees", icon: Users, path: "/employees" },
    { id: "attendance", label: "Attendance", icon: CalendarDays, path: "/attendance", },
    { id: "leave", label: "Leave", icon: CalendarClock, path: "/leave" },
    { id: "salary", label: "Salary", icon: Wallet, path: "/salary" },
    { id: "reports", label: "Reports", icon: FileText, path: "/reports" },
    { id: "settings", label: "Settings", icon: Settings, path: "/settings" },
];