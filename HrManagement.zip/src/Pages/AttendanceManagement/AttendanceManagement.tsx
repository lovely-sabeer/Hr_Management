import { useMemo, useState } from "react";
import {
    Search,
    Download,
    Check,
    X,
    CalendarClock,
    Clock3,
    Edit,
    MoreVertical,
    Users,
    UserCheck,
    UserX,
    Plane,
	Trash,
	Trash2
} from "lucide-react";
import styles from "./AttendanceManagement.module.css";
import StatCard from "../../Components/StatCard/StatCard";
import ReportTable, { type ReportTableConfig } from "../../Components/ReportTable/ReportTable";
import { attendanceTableConfig } from "../../Data/TableData";

type AtmStatus = "Present" | "Absent" | "On Leave" | "Half Day" | "Late Entry";

type AtmEmployee = {
    id: number;
    employeeId: string;
    name: string;
    email: string;
    department: string;
    date: string;
    status: AtmStatus;
    avatar: string;
};

const attendanceStats = [
    {
        id: 1,
        title: "Total Employees",
        value: "1,248",
        change: "+2.4%",
        changeType: "success",
        icon: Users,
    },
    {
        id: 2,
        title: "Present Today",
        value: "1,148",
        change: "92%",
        changeType: "success",
        icon: UserCheck,
    },
    {
        id: 3,
        title: "Absent Today",
        value: "52",
        change: "4.2%",
        changeType: "danger",
        icon: UserX,
    },
    {
        id: 4,
        title: "On Leave",
        value: "48",
        change: "Active",
        changeType: "warning",
        icon: Plane,
    },
];

const departmentOptions = [
    "All Departments",
    "Engineering",
    "Design",
    "Marketing",
    "HR",
    "Finance",
];

const statusOptions = [
    "All Status",
    "Present",
    "Absent",
    "On Leave",
    "Half Day",
    "Late Entry",
];

const attendanceRows: AtmEmployee[] = [
    {
        id: 1,
        employeeId: "#EMP-2041",
        name: "Alex Rivers",
        email: "alex.r@nexus.com",
        department: "Engineering",
        date: "14 Mar 2026",
        status: "Present",
        avatar: "https://i.pravatar.cc/150?img=11",
    },
    {
        id: 2,
        employeeId: "#EMP-2042",
        name: "Sarah Chen",
        email: "sarah.c@nexus.com",
        department: "Design",
        date: "14 Mar 2026",
        status: "Absent",
        avatar: "https://i.pravatar.cc/150?img=12",
    },
    {
        id: 3,
        employeeId: "#EMP-2043",
        name: "Marcus Wright",
        email: "marcus.w@nexus.com",
        department: "Marketing",
        date: "14 Mar 2026",
        status: "On Leave",
        avatar: "https://i.pravatar.cc/150?img=13",
    },
    {
        id: 4,
        employeeId: "#EMP-2044",
        name: "Elena Sofia",
        email: "elena.s@nexus.com",
        department: "Engineering",
        date: "14 Mar 2026",
        status: "Late Entry",
        avatar: "https://i.pravatar.cc/150?img=14",
    },
    {
        id: 5,
        employeeId: "#EMP-2045",
        name: "James Carter",
        email: "james.c@nexus.com",
        department: "HR",
        date: "14 Mar 2026",
        status: "Half Day",
        avatar: "https://i.pravatar.cc/150?img=15",
    },
];

const paginationData = {
    currentPage: 1,
    totalPages: 12,
    totalRecords: 1248,
    start: 1,
    end: 10,
};

//new 
const AtmToolbar = ({
    search,
    setSearch,
    department,
    setDepartment,
    status,
    setStatus,
}: any) => (
    <div className={styles.Atm__toolbar}>
        <div className={styles.Atm__toolbarLeft}>
            <div className={styles.Atm__search}>
                <Search size={18} />
                <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search employees..."
                />
            </div>

            <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
            >
                {departmentOptions.map((item) => (
                    <option key={item}>{item}</option>
                ))}
            </select>

            <select value={status} onChange={(e) => setStatus(e.target.value)}>
                {statusOptions.map((item) => (
                    <option key={item}>{item}</option>
                ))}
            </select>
        </div>

        <div className={styles.Atm__toolbarRight}>
            <button className={styles.Atm__secondaryBtn}>
                <Download size={16} />
                <span>Download</span>
            </button>

            <button className={styles.Atm__primaryBtn}>
                <Check size={16} />
                <span>Mark Attendance</span>
            </button>
        </div>
    </div>
);

const AtmBulkActions = ({ selectedCount }: { selectedCount: number }) => {
    if (!selectedCount) return null;

    return (
        <div className={styles.Atm__bulkActions}>
            <span>{selectedCount} Selected</span>
            <div className={styles.Atm__bulkButtons}>
                <button>
                    <Check size={14} />
                    Present
                </button>

                <button>
                    <X size={14} />
                    Absent
                </button>

                <button>
                    <Plane size={14} />
                    Leave
                </button>

                <button>
                    <Clock3 size={14} />
                    Half Day
                </button>
            </div>
        </div>
    );
};
const AttendanceManagement = () => {
    const [search, setSearch] = useState("");
    const [department, setDepartment] = useState("All Departments");
    const [status, setStatus] = useState("All Status");

	const [selectedRows, setSelectedRows] = useState<number[]>([]);

	const handleSelectRow = (id: number) => {
		setSelectedRows((prev) =>
			prev.includes(id)
				? prev.filter((item) => item !== id)
				: [...prev, id]
		);
	};

	const handleSelectAll = () => {
		if (
			selectedRows.length ===
			attendanceTableConfig.rows.length
		) {
			setSelectedRows([]);
			return;
		}

		setSelectedRows(
			attendanceTableConfig.rows.map((row) => row.id)
		);
	};

	const handleActionClick = (
		action: string,
		row: any
	) => {
		switch (action) {
			case "edit":
				console.log("Edit", row);
				break;

			case "delete":
				console.log("Delete", row);
				break;
		}
	};

    return (
        <div className={styles.Atm__container}>
            <div className={styles.Atm__statGrid}>
                {attendanceStats.map((card) => (
                    <StatCard card={card} />
                ))}
            </div>

            <AtmToolbar
                search={search}
                setSearch={setSearch}
                department={department}
                setDepartment={setDepartment}
                status={status}
                setStatus={setStatus}
            />

            <AtmBulkActions selectedCount={selectedRows.length} />

			<ReportTable
				config={attendanceTableConfig}
				selectedRows={selectedRows}
				onSelectRow={handleSelectRow}
				onSelectAll={handleSelectAll}
				onActionClick={handleActionClick}
			/>
        </div>
    );
};

export default AttendanceManagement;